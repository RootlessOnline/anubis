#!/usr/bin/env python3
"""
WhatsApp Tool for Anubis V2
- Shows QR code for scanning
- Saves session (scan once, remembers forever)
- Send and receive messages
"""

import os
import json
import asyncio
from pathlib import Path

# Session storage
SESSION_DIR = Path.home() / ".anubis" / "sessions"
SESSION_DIR.mkdir(parents=True, exist_ok=True)
WHATSAPP_SESSION = SESSION_DIR / "whatsapp_session.json"


def get_whatsapp_status():
    """Check WhatsApp session status"""
    if WHATSAPP_SESSION.exists():
        with open(WHATSAPP_SESSION, 'r') as f:
            data = json.load(f)
            return {
                "setup": data.get("authenticated", False),
                "phone": data.get("phone", "Unknown"),
                "last_used": data.get("last_used", "Never")
            }
    return {"setup": False, "phone": None, "last_used": None}


def save_whatsapp_session(phone="Unknown"):
    """Save WhatsApp session"""
    from datetime import datetime
    data = {
        "authenticated": True,
        "phone": phone,
        "last_used": datetime.now().isoformat()
    }
    with open(WHATSAPP_SESSION, 'w') as f:
        json.dump(data, f, indent=2)


def check_playwright():
    """Check if Playwright is installed"""
    try:
        import playwright
        return True
    except ImportError:
        return False


def install_playwright():
    """Install Playwright"""
    import subprocess
    print("📦 Installing Playwright (one-time setup)...")
    subprocess.run(["pip", "install", "playwright"], check=True)
    print("🌐 Installing browser...")
    subprocess.run(["playwright", "install", "chromium"], check=True)
    print("✅ Playwright ready!")


def setup_whatsapp():
    """
    Setup WhatsApp Web with QR code scanning.
    Returns instructions and starts browser.
    """
    status = get_whatsapp_status()
    
    if status["setup"]:
        return f"""✅ WhatsApp Already Configured!
📱 Phone: {status['phone']}
🕒 Last used: {status['last_used']}

To send a message, say:
  'Send WhatsApp to [contact name]: [message]'

Example:
  'Send WhatsApp to Mom: Hi, how are you?'
"""

    # Check Playwright
    if not check_playwright():
        install_playwright()
    
    # Create setup script
    setup_code = '''
import asyncio
from playwright.async_api import async_playwright
import json
from pathlib import Path
from datetime import datetime

SESSION_DIR = Path.home() / ".anubis" / "sessions"
WHATSAPP_SESSION = SESSION_DIR / "whatsapp_session.json"

async def main():
    print("\\n🐺 Opening WhatsApp Web...")
    print("📱 Scan the QR code with your phone!")
    print("   WhatsApp > Settings > Linked Devices > Link a Device\\n")
    
    async with async_playwright() as p:
        # Use persistent context to save session
        user_data = Path.home() / ".anubis" / "whatsapp_data"
        user_data.mkdir(parents=True, exist_ok=True)
        
        browser = await p.chromium.launch_persistent_context(
            str(user_data),
            headless=False,
            viewport={"width": 1200, "height": 800}
        )
        
        page = browser.pages[0] if browser.pages else await browser.new_page()
        
        await page.goto("https://web.whatsapp.com")
        
        print("🔍 Waiting for you to scan QR code...")
        print("   (The browser window is open - scan with your phone!)")
        
        # Wait for QR code to be scanned (main page loads)
        try:
            await page.wait_for_selector('[data-testid="chat-list"]', timeout=120000)
            
            # Get phone number if visible
            try:
                phone_elem = await page.query_selector("header span[title]")
                phone = await phone_elem.get_attribute("title") if phone_elem else "Connected"
            except:
                phone = "Connected"
            
            # Save session
            data = {
                "authenticated": True,
                "phone": phone,
                "last_used": datetime.now().isoformat()
            }
            with open(WHATSAPP_SESSION, 'w') as f:
                json.dump(data, f, indent=2)
            
            print(f"\\n✅ WhatsApp Connected! Phone: {phone}")
            print("🐺 Anubis will remember this session!")
            print("\\nClose the browser when done, or:")
            print("   Say 'send WhatsApp to [contact]: [message]'")
            
            # Keep browser open for user
            await page.wait_for_timeout(300000)  # 5 minutes
            
        except Exception as e:
            print(f"\\n⏱️ Timeout or error: {e}")
            print("   Run setup again when ready!")
        
        await browser.close()

asyncio.run(main())
'''
    
    # Save and run setup script
    setup_file = Path.home() / ".anubis" / "whatsapp_setup.py"
    setup_file.parent.mkdir(parents=True, exist_ok=True)
    with open(setup_file, 'w') as f:
        f.write(setup_code)
    
    return f"""🐺 WhatsApp Setup Instructions:

1️⃣ A browser window will open
2️⃣ Open WhatsApp on your phone
3️⃣ Go to: Settings > Linked Devices > Link a Device
4️⃣ Scan the QR code in the browser
5️⃣ Done! Anubis will remember your session

Run this command in a NEW terminal:

    cd ~/Documents/Anubis && source venv/bin/activate && python ~/.anubis/whatsapp_setup.py

Or say 'open whatsapp browser' to have Anubis run it for you!
"""


def open_whatsapp_browser():
    """Run the WhatsApp setup browser"""
    import subprocess
    
    setup_file = Path.home() / ".anubis" / "whatsapp_setup.py"
    
    if not setup_file.exists():
        # Create it first
        setup_whatsapp()
    
    # Run in background
    subprocess.Popen(
        ["python", str(setup_file)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    
    return """🐺 Opening WhatsApp Web browser...
📱 Scan the QR code with your phone!
   WhatsApp > Settings > Linked Devices > Link a Device

The browser window should open shortly.
After scanning, your session will be saved forever!
"""


def send_whatsapp_message(contact: str, message: str):
    """Send a WhatsApp message to a contact"""
    status = get_whatsapp_status()
    
    if not status["setup"]:
        return """❌ WhatsApp not set up yet!

Say: 'setup whatsapp' first to scan QR code.
"""
    
    send_code = f'''
import asyncio
from playwright.async_api import async_playwright
from datetime import datetime
import json
from pathlib import Path

SESSION_DIR = Path.home() / ".anubis" / "sessions"
WHATSAPP_SESSION = SESSION_DIR / "whatsapp_session.json"

async def main():
    contact = "{contact}"
    message = "{message}"
    
    async with async_playwright() as p:
        user_data = Path.home() / ".anubis" / "whatsapp_data"
        browser = await p.chromium.launch_persistent_context(
            str(user_data),
            headless=False,
            viewport={{"width": 1200, "height": 800}}
        )
        
        page = browser.pages[0] if browser.pages else await browser.new_page()
        await page.goto("https://web.whatsapp.com")
        
        # Wait for chat list
        await page.wait_for_selector('[data-testid="chat-list"]', timeout=30000)
        
        # Search for contact
        search = await page.query_selector('[data-testid="search"] input, [title="Search"] input, #side input')
        if search:
            await search.fill(contact)
            await page.wait_for_timeout(2000)
        
        # Click on contact
        contacts = await page.query_selector_all('[data-testid="cell-frame-container"]')
        for c in contacts:
            text = await c.inner_text()
            if contact.lower() in text.lower():
                await c.click()
                break
        
        # Type message
        msg_box = await page.query_selector('[data-testid="conversation-compose-box-input"], [title="Type a message"]')
        if msg_box:
            await msg_box.fill(message)
            await page.wait_for_timeout(500)
            
            # Send
            send_btn = await page.query_selector('[data-testid="send-message-button"], [data-icon="send"]')
            if send_btn:
                await send_btn.click()
                print(f"✅ Message sent to {{contact}}: {{message}}")
            else:
                await msg_box.press("Enter")
                print(f"✅ Message sent to {{contact}}!")
        else:
            print(f"❌ Could not find message box. Is {{contact}} in your contacts?")
        
        # Update session
        with open(WHATSAPP_SESSION, 'r') as f:
            data = json.load(f)
        data["last_used"] = datetime.now().isoformat()
        with open(WHATSAPP_SESSION, 'w') as f:
            json.dump(data, f, indent=2)
        
        await page.wait_for_timeout(2000)
        await browser.close()

asyncio.run(main())
'''
    
    # Save and run
    send_file = Path.home() / ".anubis" / "whatsapp_send.py"
    with open(send_file, 'w') as f:
        f.write(send_code)
    
    import subprocess
    result = subprocess.run(
        ["python", str(send_file)],
        capture_output=True,
        text=True,
        timeout=60
    )
    
    if result.returncode == 0:
        return f"✅ Message sent to {contact}: {message}"
    else:
        return f"❌ Error: {result.stderr or 'Could not send message'}"


# CLI interface
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python whatsapp_tool.py [setup|send|status]")
        sys.exit(1)
    
    cmd = sys.argv[1]
    
    if cmd == "setup":
        print(setup_whatsapp())
    elif cmd == "status":
        status = get_whatsapp_status()
        print(f"📱 WhatsApp Status: {'✅ Connected' if status['setup'] else '❌ Not set up'}")
        if status['setup']:
            print(f"   Phone: {status['phone']}")
    elif cmd == "send":
        if len(sys.argv) < 4:
            print("Usage: python whatsapp_tool.py send 'contact' 'message'")
        else:
            print(send_whatsapp_message(sys.argv[2], sys.argv[3]))
    else:
        print(f"Unknown command: {cmd}")
