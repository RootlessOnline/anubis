"""
Bash Tool - Execute Terminal Commands

This gives Anubis the ability to:
- Run any terminal/bash command
- Navigate filesystem
- Install packages
- Run scripts and applications
- Start background services
"""

import os
import sys
import subprocess
import signal
import time
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class CommandResult:
    """Result of a bash command"""
    success: bool
    command: str
    stdout: str
    stderr: str
    return_code: int
    execution_time: float


class BashTool:
    """Execute bash commands"""
    
    def __init__(self, working_dir: str = None, timeout: int = 300):
        self.working_dir = working_dir or os.path.expanduser("~")
        self.timeout = timeout
        self.running_processes: Dict[str, subprocess.Popen] = {}
        
    def execute(self, command: str, cwd: str = None, timeout: int = None) -> CommandResult:
        """Execute a bash command"""
        start_time = time.time()
        cwd = cwd or self.working_dir
        timeout = timeout or self.timeout
        
        os.makedirs(cwd, exist_ok=True)
        
        try:
            result = subprocess.run(
                command, shell=True, cwd=cwd,
                capture_output=True, text=True, timeout=timeout
            )
            
            return CommandResult(
                success=result.returncode == 0,
                command=command,
                stdout=result.stdout or "",
                stderr=result.stderr or "",
                return_code=result.returncode,
                execution_time=time.time() - start_time
            )
        except subprocess.TimeoutExpired:
            return CommandResult(False, command, "", f"Timeout after {timeout}s", -1, time.time() - start_time)
        except Exception as e:
            return CommandResult(False, command, "", str(e), -1, time.time() - start_time)
    
    def execute_async(self, command: str, name: str = None) -> Tuple[str, int]:
        """Execute in background"""
        name = name or f"process_{int(time.time())}"
        process = subprocess.Popen(
            command, shell=True, cwd=self.working_dir,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            preexec_fn=os.setsid
        )
        self.running_processes[name] = process
        return name, process.pid
    
    def stop_process(self, name: str) -> bool:
        """Stop background process"""
        if name in self.running_processes:
            try:
                os.killpg(os.getpgid(self.running_processes[name].pid), signal.SIGTERM)
            except:
                pass
            del self.running_processes[name]
            return True
        return False
    
    def list_processes(self) -> List[Dict]:
        """List running processes"""
        return [{"name": n, "pid": p.pid, "running": p.poll() is None} 
                for n, p in self.running_processes.items()]


class BashToolWrapper:
    """Wrapper for Anubis tool system"""
    
    def __init__(self):
        self.bash = BashTool()
    
    def run_command(self, command: str) -> str:
        """Run command and return result"""
        result = self.bash.execute(command)
        output = [f"$ {command}", f"[Exit: {result.return_code}]"]
        if result.stdout:
            output.append(result.stdout)
        if result.stderr:
            output.append(f"[stderr]\n{result.stderr}")
        return "\n".join(output)
    
    def start_service(self, command: str, name: str) -> str:
        process_name, pid = self.bash.execute_async(command, name)
        return f"Started '{process_name}' with PID {pid}"
    
    def stop_service(self, name: str) -> str:
        return f"Stopped '{name}'" if self.bash.stop_process(name) else f"Service '{name}' not found"
    
    def list_services(self) -> str:
        processes = self.bash.list_processes()
        if not processes:
            return "No background services"
        return "\n".join([f"  - {p['name']}: PID {p['pid']} ({'running' if p['running'] else 'stopped'})" 
                         for p in processes])


# Tool definitions
TOOLS = [
    {"name": "bash", "description": "Execute bash commands", "function": "run_bash_command",
     "parameters": {"command": {"type": "string"}}, "category": "system"},
    {"name": "start_service", "description": "Start background service", "function": "start_background_service",
     "parameters": {"command": {"type": "string"}, "name": {"type": "string"}}, "category": "system"},
    {"name": "stop_service", "description": "Stop background service", "function": "stop_background_service",
     "parameters": {"name": {"type": "string"}}, "category": "system"},
    {"name": "list_services", "description": "List running services", "function": "list_background_services",
     "parameters": {}, "category": "system"}
]

_bash_wrapper = None

def get_bash_tool() -> BashToolWrapper:
    global _bash_wrapper
    if _bash_wrapper is None:
        _bash_wrapper = BashToolWrapper()
    return _bash_wrapper

def run_bash_command(command: str) -> str:
    return get_bash_tool().run_command(command)

def start_background_service(command: str, name: str) -> str:
    return get_bash_tool().start_service(command, name)

def stop_background_service(name: str) -> str:
    return get_bash_tool().stop_service(name)

def list_background_services() -> str:
    return get_bash_tool().list_services()
