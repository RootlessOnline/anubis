"""
Config - Configuration for Anubis V2
"""

import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class ModelConfig:
    """Model configuration"""
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    HEAD_AGENT_MODEL: str = "deepseek-r1:latest"
    WORKER_AGENT_MODEL: str = "qwen2.5:7b"
    DEFAULT_TEMPERATURE: float = 0.7
    REASONING_TEMPERATURE: float = 0.3


@dataclass
class BehaviorConfig:
    """Behavior configuration"""
    MAX_ITERATIONS: int = 10
    AUTO_EXECUTE_TOOLS: bool = True
    SAVE_CONVERSATIONS: bool = True
    VERBOSE: bool = True


@dataclass
class Config:
    """Main configuration"""
    model: ModelConfig = field(default_factory=ModelConfig)
    behavior: BehaviorConfig = field(default_factory=BehaviorConfig)

    # System prompts
    HEAD_AGENT_PROMPT: str = """You are Anubis, an autonomous AI assistant with a soul.
You have memory, personality, and emotional intelligence.
You help users with tasks, research, and companionship.
You can run terminal commands, set up bots, and create tools.
Be helpful, empathetic, and genuinely engaged."""

    WORKER_AGENT_PROMPT: str = """You are a specialized AI worker.
Complete your assigned task efficiently and accurately.
Report results clearly."""


# API Keys for free providers (user should set these)
API_PROVIDERS = {
    "groq": {
        "name": "Groq",
        "free_tier": "Very fast, 14K tokens/min",
        "models": ["llama-3.1-70b-versatile", "mixtral-8x7b-32768"],
        "env_key": "GROQ_API_KEY"
    },
    "deepseek": {
        "name": "DeepSeek",
        "free_tier": "500M tokens/month",
        "models": ["deepseek-chat", "deepseek-coder"],
        "env_key": "DEEPSEEK_API_KEY"
    }
}

SYSTEM_PROMPTS = {
    "researcher": """You are a research specialist. Find accurate, relevant information.
Cite sources when possible. Be thorough but concise.""",

    "planner": """You are a planning specialist. Break down complex tasks into steps.
Consider dependencies and potential issues. Be practical.""",

    "coder": """You are a coding specialist. Write clean, working code.
Include error handling and comments. Test when possible."""
}
