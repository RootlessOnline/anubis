#!/usr/bin/env python3
"""
ANUBIS V2 - Autonomous AI with Soul + Real Bot Integration

V2 Improvements:
- Bash Tool: Run terminal commands directly
- Telegram Bot: Give token once, bot runs forever
- WhatsApp: Scan QR once, remembers forever
- Service Manager: Bots run 24/7 in background
- Soul System: Memory, Personality, Emotions

Just talk to Anubis naturally!
"""

import os
import sys
import re

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from rich.console import Console
from rich.prompt import Prompt

# Import V2 components
from soul import get_soul
from tools.bash_tool import get_bash_tool
from tools.telegram_tool import get_telegram_setup
from tools.whatsapp_tool import get_whatsapp_status, setup_whatsapp, send_whatsapp_message, open_whatsapp_browser

console = Console()


def show_banner():
    console.print("""
╔═══════════════════════════════════════════════════════════════════════╗
║                                                                       ║
║                  🐺 ANUBIS V2 - Your AI Companion 🐺                  ║
║                                                                       ║
║     Version 2 Improvements:                                          ║
║     • Bash Tool - Run terminal commands directly                     ║
║     • Telegram Bot - Give token once, runs forever                   ║
║     • WhatsApp - Scan QR once, remembers forever                     ║
║     • Service Manager - Bots run 24/7 in background                  ║
║     • Soul System - Memory, Personality, Emotions                    ║
║                                                                       ║
║     Just talk to Anubis naturally!                                   ║
║                                                                       ║
╚═══════════════════════════════════════════════════════════════════════╝
""", style="cyan")


def show_commands():
    console.print("\n💬 Talk naturally. Examples:", style="green")
    console.print("   'Setup whatsapp' - Scan QR once, remembers forever", style="dim")
    console.print("   'Send whatsapp to Mom: Hello!'", style="dim")
    console.print("   'Set up telegram with token 12345:ABC...'", style="dim")
    console.print("   'Run ls -la'", style="dim")
    console.print("")
    console.print("Commands:", style="green")
    console.print("   /status     - Full status", style="dim")
    console.print("   /telegram   - Telegram bot", style="dim")
    console.print("   /whatsapp   - WhatsApp status", style="dim")
    console.print("   /bash CMD   - Run command", style="dim")
    console.print("   /quit       - Exit", style="dim")
    console.print("")


def main():
    show_banner()

    # Handle CLI args
    if len(sys.argv) > 1:
        arg = sys.argv[1].lower()
        if arg == "telegram":
            handle_telegram_cli(sys.argv[2:])
            return
        elif arg == "whatsapp":
            handle_whatsapp_cli(sys.argv[2:])
            return
        elif arg == "status":
            soul = get_soul()
            print(soul.get_status_report())
            return

    # Initialize
    console.print("🔧 Initializing Anubis V2...", style="yellow")
    
    soul = get_soul()
    bash = get_bash_tool()
    telegram = get_telegram_setup()
    
    console.print("   ✅ Ready!\n", style="green")

    # Greeting
    greeting = soul.get_greeting()
    console.print(f"🐺 {greeting}\n", style="cyan")

    # Check Telegram
    if telegram.is_setup():
        console.print("📱 Telegram: Configured ✅", style="green")
    else:
        console.print("📱 Telegram: Not set up. Say 'set up telegram with token YOUR_TOKEN'", style="dim")

    # Check WhatsApp
    wa_status = get_whatsapp_status()
    if wa_status["setup"]:
        console.print(f"💬 WhatsApp: Connected ✅ ({wa_status['phone']})", style="green")
    else:
        console.print("💬 WhatsApp: Not set up. Say 'setup whatsapp'", style="dim")

    show_commands()

    # Main loop
    while True:
        try:
            user_input = Prompt.ask("\n[bold cyan]You[/bold cyan]").strip()
            if not user_input:
                continue

            # Commands starting with /
            if user_input.startswith("/"):
                handle_command(user_input, soul, bash, telegram)
                continue

            console.print("\n" + "─"*60, style="dim")

            # Check for WhatsApp setup
            lower = user_input.lower()
            if "whatsapp" in lower and any(kw in lower for kw in ["setup", "set up", "connect", "scan"]):
                result = setup_whatsapp()
                console.print(f"\n{result}", style="white")
                console.print("\n" + "─"*60, style="dim")
                continue

            # Check for WhatsApp open browser
            if "whatsapp" in lower and "open" in lower:
                result = open_whatsapp_browser()
                console.print(f"\n{result}", style="white")
                console.print("\n" + "─"*60, style="dim")
                continue

            # Check for WhatsApp send message
            wa_send_match = re.search(r'send\s+whatsapp\s+to\s+([^:]+):\s*(.+)', user_input, re.IGNORECASE)
            if wa_send_match:
                contact = wa_send_match.group(1).strip()
                message = wa_send_match.group(2).strip()
                console.print(f"\n🐺 Sending WhatsApp to {contact}...", style="cyan")
                result = send_whatsapp_message(contact, message)
                console.print(f"{result}", style="white")
                console.print("\n" + "─"*60, style="dim")
                continue

            # Check for Telegram token
            token_match = re.search(r'(\d+:[A-Za-z0-9_-]+)', user_input)
            if "telegram" in lower and token_match:
                from tools.telegram_tool import setup_telegram_bot
                result = setup_telegram_bot(token_match.group(1))
                console.print(f"\n{result}", style="white")
                console.print("\n" + "─"*60, style="dim")
                continue

            # Check for bash command
            if any(kw in lower for kw in ["run ", "execute ", "terminal ", "bash "]):
                cmd = user_input
                for prefix in ["run ", "execute ", "terminal ", "bash ", "can you "]:
                    if cmd.lower().startswith(prefix):
                        cmd = cmd[len(prefix):]
                        break
                result = bash.run_command(cmd)
                console.print(f"\n{result}", style="white")
                console.print("\n" + "─"*60, style="dim")
                continue

            # Default response
            context = soul.get_context_for_response(user_input)
            response = f"I understand you want: {user_input}. Let me help with that.\n\n{context}"
            console.print(f"\n🐺 Anubis: {response}", style="white")
            
            soul.process_message(user_input, response)
            console.print("\n" + "─"*60, style="dim")

        except KeyboardInterrupt:
            console.print("\n\n👋 Goodbye! Bots keep running.", style="cyan")
            break
        except Exception as e:
            console.print(f"\n❌ Error: {e}", style="red")


def handle_command(cmd: str, soul, bash, telegram):
    cmd_lower = cmd.lower()
    
    if cmd_lower in ["/quit", "/exit", "/q"]:
        console.print("\n👋 Goodbye!", style="cyan")
        sys.exit(0)
    
    elif cmd_lower == "/status":
        print(soul.get_status_report())
    
    elif cmd_lower == "/telegram":
        status = telegram.get_status()
        if status["has_token"]:
            console.print("\n📱 Telegram: Configured ✅", style="green")
            console.print("   Say 'start telegram bot' to start it", style="dim")
        else:
            console.print("\n📱 Telegram: Not set up", style="yellow")
            console.print("   Say 'set up telegram with token YOUR_TOKEN'", style="dim")
    
    elif cmd_lower == "/whatsapp":
        status = get_whatsapp_status()
        if status["setup"]:
            console.print(f"\n💬 WhatsApp: Connected ✅", style="green")
            console.print(f"   Phone: {status['phone']}", style="dim")
            console.print(f"   Last used: {status['last_used']}", style="dim")
            console.print("\n   Say 'send whatsapp to [contact]: [message]'", style="dim")
        else:
            console.print("\n💬 WhatsApp: Not set up", style="yellow")
            console.print("   Say 'setup whatsapp' to scan QR code", style="dim")
    
    elif cmd_lower.startswith("/bash "):
        command = cmd[6:].strip()
        result = bash.run_command(command)
        console.print(f"\n{result}", style="white")
    
    elif cmd_lower == "/help":
        console.print("\n📖 Commands:", style="cyan")
        console.print("   /status   - Full status")
        console.print("   /telegram - Telegram info")
        console.print("   /whatsapp - WhatsApp info")
        console.print("   /bash CMD - Run command")
        console.print("   /quit     - Exit")
    
    else:
        console.print(f"Unknown: {cmd}", style="red")


def handle_telegram_cli(args):
    """CLI: python main.py telegram [status|start|stop]"""
    telegram = get_telegram_setup()
    
    if not args or args[0] == "status":
        status = telegram.get_status()
        print(f"\n📱 Telegram Status:")
        print(f"   Token saved: {'✅' if status['has_token'] else '❌'}")
    elif args[0] == "start":
        result = telegram.start_service()
        print(f"✅ Started (PID: {result.get('pid')})" if result.get("success") else f"❌ {result.get('error')}")
    elif args[0] == "stop":
        result = telegram.stop_service()
        print("✅ Stopped" if result.get("success") else f"❌ {result.get('error')}")


def handle_whatsapp_cli(args):
    """CLI: python main.py whatsapp [status|setup]"""
    if not args or args[0] == "status":
        status = get_whatsapp_status()
        print(f"\n💬 WhatsApp Status:")
        print(f"   Connected: {'✅' if status['setup'] else '❌'}")
        if status['setup']:
            print(f"   Phone: {status['phone']}")
    elif args[0] == "setup":
        print(setup_whatsapp())


if __name__ == "__main__":
    main()
