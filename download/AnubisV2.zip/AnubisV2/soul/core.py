"""
Anubis Soul - Memory, Personality, Emotions

This gives Anubis the ability to:
- Remember conversations
- Track personality growth
- Understand emotions
- Persist sessions
"""

import os
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict


# ============ MEMORY ============

@dataclass
class Memory:
    id: str
    content: str
    memory_type: str
    timestamp: str
    importance: float = 0.5
    tags: List[str] = field(default_factory=list)


class MemoryStore:
    """Stores and retrieves memories"""
    
    def __init__(self, memory_dir: str = None):
        self.memory_dir = memory_dir or os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "memory"
        )
        os.makedirs(self.memory_dir, exist_ok=True)
        self.memories: Dict[str, Memory] = {}
        self._load()
    
    def _load(self):
        """Load memories from disk"""
        for root, dirs, files in os.walk(self.memory_dir):
            for f in files:
                if f.endswith(".json"):
                    try:
                        with open(os.path.join(root, f), 'r') as file:
                            data = json.load(file)
                            self.memories[data["id"]] = Memory(**data)
                    except:
                        pass
    
    def store(self, content: str, memory_type: str = "episodic", 
              importance: float = 0.5, tags: List[str] = None) -> Memory:
        """Store a memory"""
        mem_id = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{len(self.memories)}"
        memory = Memory(
            id=mem_id,
            content=content,
            memory_type=memory_type,
            timestamp=datetime.now().isoformat(),
            importance=importance,
            tags=tags or []
        )
        self.memories[mem_id] = memory
        
        # Save to disk
        type_dir = os.path.join(self.memory_dir, memory_type)
        os.makedirs(type_dir, exist_ok=True)
        with open(os.path.join(type_dir, f"{mem_id}.json"), 'w') as f:
            json.dump(asdict(memory), f)
        
        return memory
    
    def recall(self, query: str = None, limit: int = 10) -> List[Memory]:
        """Recall memories"""
        results = []
        for mem in self.memories.values():
            if query and query.lower() in mem.content.lower():
                results.append(mem)
            elif not query:
                results.append(mem)
        
        results.sort(key=lambda m: m.importance, reverse=True)
        return results[:limit]


# ============ PERSONALITY ============

@dataclass
class PersonalityTrait:
    name: str
    value: float
    base_value: float
    experiences: List[Dict] = field(default_factory=list)


class PersonalitySystem:
    """Manages Anubis's evolving personality"""
    
    DEFAULT_TRAITS = {
        "curiosity": 0.8,
        "empathy": 0.75,
        "loyalty": 0.9,
        "wisdom": 0.3,
        "creativity": 0.6,
        "humor": 0.4,
        "patience": 0.7,
        "supportiveness": 0.8
    }
    
    def __init__(self, personality_file: str = None):
        self.personality_file = personality_file or os.path.join(
            os.path.dirname(os.path.dirname(__file__)), 
            "memory", "semantic", "personality.json"
        )
        os.makedirs(os.path.dirname(self.personality_file), exist_ok=True)
        
        self.traits: Dict[str, PersonalityTrait] = {}
        self._load()
    
    def _load(self):
        """Load personality"""
        if os.path.exists(self.personality_file):
            try:
                with open(self.personality_file, 'r') as f:
                    data = json.load(f)
                    for name, t in data.get("traits", {}).items():
                        self.traits[name] = PersonalityTrait(
                            name=name, value=t["value"], base_value=t.get("base_value", t["value"]),
                            experiences=t.get("experiences", [])
                        )
                return
            except:
                pass
        
        # Create default
        for name, value in self.DEFAULT_TRAITS.items():
            self.traits[name] = PersonalityTrait(name=name, value=value, base_value=value)
        self._save()
    
    def _save(self):
        """Save personality"""
        data = {
            "traits": {
                name: {"value": t.value, "base_value": t.base_value, "experiences": t.experiences[-20:]}
                for name, t in self.traits.items()
            },
            "last_saved": datetime.now().isoformat()
        }
        with open(self.personality_file, 'w') as f:
            json.dump(data, f, indent=2)
    
    def grow(self, trait: str, amount: float, reason: str = ""):
        """Grow a trait"""
        if trait in self.traits:
            t = self.traits[trait]
            old = t.value
            t.value = max(0, min(1, t.value + amount))
            t.experiences.append({
                "timestamp": datetime.now().isoformat(),
                "change": amount,
                "reason": reason,
                "before": old,
                "after": t.value
            })
            self._save()
    
    def get_context(self) -> str:
        """Get personality context for prompts"""
        top = sorted(self.traits.items(), key=lambda x: -x[1].value)[:5]
        return f"Top traits: {', '.join([f'{n} ({t.value:.0%})' for n, t in top])}"


# ============ USER PROFILE ============

class UserProfile:
    """User information and preferences"""
    
    def __init__(self, profile_file: str = None):
        self.profile_file = profile_file or os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            "memory", "semantic", "user_profile.json"
        )
        os.makedirs(os.path.dirname(self.profile_file), exist_ok=True)
        self.profile = self._load()
    
    def _load(self) -> Dict:
        if os.path.exists(self.profile_file):
            try:
                with open(self.profile_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        
        return {
            "name": "Friend",
            "first_met": datetime.now().isoformat(),
            "total_conversations": 0,
            "relationship_level": 0.0,
            "interests": [],
            "memorable_moments": []
        }
    
    def save(self):
        with open(self.profile_file, 'w') as f:
            json.dump(self.profile, f, indent=2)
    
    def update(self, key: str, value: Any):
        self.profile[key] = value
        self.save()
    
    def increment_conversation(self):
        self.profile["total_conversations"] += 1
        self.profile["relationship_level"] = min(100, self.profile["relationship_level"] + 0.5)
        self.save()
    
    def get_summary(self) -> str:
        days = (datetime.now() - datetime.fromisoformat(self.profile["first_met"])).days
        return f"Known for {days} days, {self.profile['total_conversations']} conversations"


# ============ SESSION MANAGER ============

class SessionManager:
    """Persist platform connections"""
    
    def __init__(self, sessions_dir: str = None):
        self.sessions_dir = sessions_dir or os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "sessions"
        )
        os.makedirs(self.sessions_dir, exist_ok=True)
        self.sessions_file = os.path.join(self.sessions_dir, "platforms.json")
        self.sessions = self._load()
    
    def _load(self) -> Dict:
        if os.path.exists(self.sessions_file):
            try:
                with open(self.sessions_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        return {"platforms": {}}
    
    def save(self):
        with open(self.sessions_file, 'w') as f:
            json.dump(self.sessions, f, indent=2)
    
    def save_platform(self, platform: str, credentials: Dict, metadata: Dict = None):
        self.sessions["platforms"][platform] = {
            "credentials": credentials,
            "metadata": metadata or {},
            "is_active": True,
            "created_at": datetime.now().isoformat()
        }
        self.save()
    
    def get_platform(self, platform: str) -> Optional[Dict]:
        return self.sessions.get("platforms", {}).get(platform)
    
    def has_platform(self, platform: str) -> bool:
        return platform in self.sessions.get("platforms", {})
    
    def list_platforms(self) -> List[str]:
        return list(self.sessions.get("platforms", {}).keys())


# ============ SOUL CORE ============

class AnubisSoul:
    """Unified soul system"""
    
    def __init__(self):
        print("🐺 Awakening Anubis's soul...")
        self.memory = MemoryStore()
        self.personality = PersonalitySystem()
        self.user_profile = UserProfile()
        self.sessions = SessionManager()
        print("   ✨ Soul awakened")
    
    def process_message(self, user_msg: str, anubis_response: str):
        """Process and remember a message"""
        self.memory.store(f"User: {user_msg}\\nAnubis: {anubis_response[:200]}", "episodic")
        self.user_profile.increment_conversation()
    
    def get_context_for_response(self, user_msg: str) -> str:
        """Get context for generating response"""
        recent = self.memory.recall(limit=3)
        context = [
            "=== ANUBIS CONTEXT ===",
            f"User: {self.user_profile.get_summary()}",
            f"Personality: {self.personality.get_context()}",
            f"Platforms: {', '.join(self.sessions.list_platforms()) or 'None'}"
        ]
        if recent:
            context.append(f"Recent memories: {len(recent)}")
        return "\\n".join(context)
    
    def get_greeting(self) -> str:
        """Get personalized greeting"""
        name = self.user_profile.profile.get("name", "Friend")
        days = (datetime.now() - datetime.fromisoformat(
            self.user_profile.profile["first_met"])).days
        
        if days == 0:
            return f"Hello! I'm Anubis. Nice to meet you, {name}!"
        elif days < 7:
            return f"Hey {name}! Good to see you again."
        else:
            return f"Welcome back, {name}! {days} days together now."
    
    def get_status_report(self) -> str:
        """Full status report"""
        profile = self.user_profile.profile
        top_traits = sorted(self.personality.traits.items(), key=lambda x: -x[1].value)[:5]
        platforms = self.sessions.list_platforms()
        
        return f"""
╔══════════════════════════════════════════════════════════════════╗
║                    🐺 ANUBIS V2 STATUS                            ║
╠══════════════════════════════════════════════════════════════════╣
║  👤 USER                                                          ║
║  ├── Name: {profile.get('name', 'Friend'):<48}║
║  ├── Days together: {(datetime.now() - datetime.fromisoformat(profile.get('first_met', datetime.now().isoformat()))).days:<43}║
║  └── Conversations: {profile.get('total_conversations', 0):<44}║
║                                                                   ║
║  🐺 PERSONALITY                                                   ║
║  └── {', '.join([f'{n}: {t.value:.0%}' for n, t in top_traits[:3]]):<53}║
║                                                                   ║
║  📱 PLATFORMS                                                     ║
║  └── {', '.join(platforms) if platforms else 'None - say "set up telegram"':<53}║
╚══════════════════════════════════════════════════════════════════╝
"""


# Singleton
_soul = None

def get_soul() -> AnubisSoul:
    global _soul
    if _soul is None:
        _soul = AnubisSoul()
    return _soul
